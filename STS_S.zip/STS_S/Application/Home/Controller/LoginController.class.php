<?php
namespace Home\Controller;
use Think\Controller;
class LoginController extends Controller {
	function login(){	// 登录模块
		$this->display();
	}

	function check_login()
	{
		session_start();
		$user = M('User');
		$condition['username'] = $_POST['username'];
		$us = $user->where($condition)->find();
		$present_time = Date("H:i:s");
		if (!$us){
			$this->error("用户名不存在");
		}
		if ($us['password']!=$_POST['password']){
			$this->error("密码错误");
		}
		$_SESSION['username'] = $_POST['username'];
		$_SESSION['userid'] = $us['userid'];
		$GLOBALS["present_time"] = Date("H:i:s");
		$GLOBALS["testCount"]=0;
 		$this->success("服务器已启动",U('Login/ServerRun'));
		//echo "		当前时间为".date("y-m-d H:i:s").";<br/>";
	}

	function check_logined(){	//检测是否已经登录
		session_start();
		$user =  M('user');
		$condition['username']  = $_SESSION['username'];
		$us = $user->where($condition)->find();
		if (!$us){
			$url = U('login');
			$this->assign("jumpUrl",$url);
			$this->error("还没有登录");
		}
	}

	function logout(){	 //注销
		$_SESSION=array();
		if(isset($_COOKIE[session_name()])){
			setcookie(session_name(),'',time()-1,'/');
		}
		session_destroy();
		$this->redirect('Index/index');
	}
	
	function serverRun(){
	    $this->display("ServerRun","utf8");
	}
	
	function chooseMode(){
	    if($_POST["mode"]=="debug"){
	        $this->display("debugMode","utf8");
	    }
	    else if($_POST["mode"]=="real"){
	        $this->success("真实模式",U('Index/serverRun'));
	    } 
	}
	
	function showDebugPage(){
	    $this->display("debugMode","utf8");
	}
	
	function doCallAuction(){
	    $base = new BaseController();
	    $base->startCallAuction();
	    $this->success("集合竞价撮合已完成",U('Login/showDebugPage'));
	}
	
	function doResetDB(){
	    $content=file_get_contents("insert.sql");
	    $arr=explode(";", $content);
	    //var_dump($arr);
	    foreach($arr as $sql){
	        if($sql==""){
	            continue;
	        }
	        $sql=trim($sql);
	        M()->execute($sql);
	    }
	    $this->success("测试数据已还原",U('Login/showDebugPage'));
	    //$Model->query("");
	    
	}
	
	
	
	
}