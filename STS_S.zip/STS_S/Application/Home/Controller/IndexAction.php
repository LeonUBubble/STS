<?php

class IndexAction extends Action {
	public function index(){
		ignore_user_abort();//关闭浏览器后，继续执行php代码
		set_time_limit(0);//程序执行时间无限制
		$sleep_time = 5;//多长时间执行一次
		$model=M("type");
		while(true){
			$msg=date("Y-m-d H:i:s");
			$data['createtime']=$msg;
			echo $msg;
			echo '<br />';
			$res=$model->add($data);
			file_put_contents("log.log",$msg,FILE_APPEND);//记录日志
			sleep($sleep_time);//等待时间，进行下一次操作。
		}
		exit();
	}
}