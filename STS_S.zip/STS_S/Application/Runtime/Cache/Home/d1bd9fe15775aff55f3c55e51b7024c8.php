<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
 	<style type="text/css">
        td,th
        {
            white-space: nowrap;//表格不分行
        }
    </style>
</head>
<body>
	<table width="200" border="1" style="margin: 0;border-collapse: collapse;">
		  <tr style="background-color:#FFF;">
		    <th scope="col">id</th>
		    <th scope="col">股票id</th>
		    <th scope="col">委托价</th>
		    <th scope="col">委托方向</th>
		    <th scope="col">委托时间</th>
		    <th scope="col">委托量</th>
		    <th scope="col">股东账号</th>
		    <th scope="col">状态</th>
		    <th scope="col">剩余量</th>
		  </tr>
		  <?php if(is_array($data)): $i = 0; $__LIST__ = $data;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><tr>
			    <td><?php echo ($vo["commissionid"]); ?></td>
			    <td><?php echo ($vo["stockid"]); ?></td>
			    <td><?php echo ($vo["commission_price"]); ?></td>
			    <td><?php echo ($vo["direction"]); ?></td>
			    <td><?php echo ($vo["time"]); ?></td>
			    <td><?php echo ($vo["commission_amount"]); ?></td>
			    <td><?php echo ($vo["stockholderid"]); ?></td>
			    <td><?php echo ($vo["state"]); ?></td>
			    <td><?php echo ($vo["remain"]); ?></td>
			  </tr><?php endforeach; endif; else: echo "" ;endif; ?>
	</table>
</body>
</html>