<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />

<title>思考练习题</title>
<script type="text/javascript">
function Buy()
{
	var target = document.getElementById("N");
	var output = document.getElementById("output");
	var myOutput = new Array();
    var j = 0 ;
	if(target.value <= 1) 
		alert("N必须是大于1的整数！！！");
	for (i = 1; i <= target.value; i++)
		{
			if(i % 7 == 0)
				myOutput[j++] = i;
		}
	output.value = myOutput;
}

</script>
<style type="text/css">
<!--
.STYLE1 {font-weight: bold}
-->
</style>
</head>

<body>
<h1 ><strong>思考练习题</strong></h1>
<hr width="100%" />
<p >
	股票id<input name="N" type="text" id="N" size="5" maxlength="30" /><br/>
	交易数量<input name="N" type="text" id="Amount" size="5" maxlength="30" /><br/>
	交易金额<input name="N" type="text" id="Price" size="5" maxlength="30" /><br/>
  	<span class="STYLE1">
  		<input type="button" name="Submit" value="购买股票" onclick = "Auction()" /><br/>
  		<input type="button" name="Submit" value="卖出股票" onclick = "Auction()" />
  	</span>
</p>

</body>
</html>