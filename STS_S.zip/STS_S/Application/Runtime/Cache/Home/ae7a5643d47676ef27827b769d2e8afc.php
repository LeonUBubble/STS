<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>测试模式</title>
</head>
<body>
	<h1>测试模式</h1>
	
	<form action="/STS_S/index.php/Home/Login/doCallAuction" method="post">
		<input type="submit" value="即刻进行集合竞价撮合">
	</form>
	<form action="/STS_S/index.php/Home/Login/doResetDB" method="post">
		<input type="submit" value="还原数据库">
	</form>
</body>
</html>