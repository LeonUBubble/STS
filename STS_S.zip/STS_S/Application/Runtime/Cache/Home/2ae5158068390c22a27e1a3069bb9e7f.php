<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>服务器启动</title>
</head>
<body>
	<h1>服务器已启动……</h1>
	
	<h3>选择服务器运行模式：</h3>
	
	<form action="/STS_S/index.php/Home/Login/chooseMode" method="post">
		<input type="radio" name="mode" value="debug">测试模式<br>
		<input type="radio" name="mode" value="real">真实模式<br>
		<input type="submit" value="Submit">
	</form>
	
</body>
</html>