<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>股票中央交易系统</title>
</head>

<body>
<h1 ><strong>股票中央交易系统</strong></h1>
<hr width="100%" />
<p >
	股票id<input name="N" type="text" id="N" size="5" maxlength="30" /><br/>
	交易数量<input name="N" type="text" id="Amount" size="5" maxlength="30" /><br/>
	交易金额<input name="N" type="text" id="Price" size="5" maxlength="30" /><br/>
  	<span class="STYLE1">
  		<input type="button" name="Submit" value="购买股票" onclick = "Auction()" /><br/>
  		<input type="button" name="Submit" value="卖出股票" onclick = "Auction()" />
  	</span>
</p>
</body>
</html>