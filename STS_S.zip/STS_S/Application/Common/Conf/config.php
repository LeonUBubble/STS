<?php
return array(
	//'配置项'=>'配置值'
	'URL_HTML_SUFFIX'=>'shtml|html|htm',
);