

drop table if exists stock_user;
create table stock_user
(
	userid int not null auto_increment,
	username varchar(20),
	password varchar(32),
	email varchar(30),
	phone_number varchar(20),
	primary key (userid)
)DEFAULT CHARSET=utf8;

drop table if exists stock_stock;
create table stock_stock
(
	stockid varchar(8) not null,
	stockname varchar(20) not null,
	isRaise enum('0','1'),
	price integer,
	totalStockNum int,
	primary key (stockid)
)DEFAULT CHARSET=utf8;

drop table if exists stock_personal_stock_account;
create table stock_personal_stock_account
(
	bankrollid int not null auto_increment,
	bankroll double, #资金余额
	bankroll_usable double, #可用资金
	bankroll_freezed double, #冻结资金
	bankroll_in_cash double, #可取资金
	total double, #总资产
	total_stock double, #股票总资产
	userid int,
	primary key (bankrollid),
	foreign key (userid) references stock_user(userid)
)DEFAULT CHARSET=utf8;

drop table if exists stock_stockholder;
create table stock_stockholder
(
	stockholderid int not null auto_increment,
	userid int,
	primary key (stockholderid),
	foreign key (userid) references stock_user(userid)
)DEFAULT CHARSET=utf8;

drop table if exists stock_hold_stock_info;
create table stock_hold_stock_info
(
	stockholderid int not null,
	stockid varchar(8) not null,
	amount_total int not null,
	amount_usable int not null,
	cost_price integer,
	foreign key (stockholderid) references stock_stockholder(stockholderid),
	foreign key (stockid) references stock_stock(stockid)
)DEFAULT CHARSET=utf8;

drop table if exists stock_commission;
create table stock_commission
(	
	commissionid int not null auto_increment,
	stockid varchar(8) not null,
	commission_price integer,
	direction enum('0','1'),	#0 买入 1 卖出
	commission_time int,
	commission_account int,
	stockholderid int,
	state enum('0','1','2'), #0 已撤销 1 已成交 2 已提交
        remain int,
	primary key (commissionid),
	foreign key (stockholderid) references stock_stockholder(stockholderid)
)DEFAULT CHARSET=utf8;

drop table if exists stock_deal;
create table stock_deal
(
	dealid int not null auto_increment,
	stockid varchar(8) not null,
	deal_price integer,
	deal_time int,
	dealed_amount int, 
	dealed_value double, #成交金额
	in_commission int not null, #买方合同编号
	out_commission int not null, #卖方合同编号
	primary key (dealid),
	foreign key (in_commission) references stock_commission(commissionid) on delete cascade,
	foreign key (out_commission) references stock_commission(commissionid) on delete cascade
)DEFAULT CHARSET=utf8;


insert into stock_user(username, password, email, phone_number)
values 
('test1','111111','111111@163.com','11111111111'),
('test2','222222','222222@163.com','22222222222'),
('test3','333333','333333@163.com','33333333333'),
('test4','444444','444444@163.com','44444444444'),
('test5','555555','555555@163.com','55555555555'),
('test6','666666','666666@163.com','66666666666'),
('test7','777777','777777@163.com','77777777777'),
('test8','888888','888888@163.com','88888888888'),
('test9','999999','999999@163.com','99999999999'),
('test10','000000','000000@163.com','00000000000');


insert into stock_stock(stockid,stockname,isRaise,price,totalStockNum)
	values
('000856','冀东装备','1',300,1000000),
('000888','峨眉山A','0',200,1000000);



insert into stock_stockholder(stockholderid, userid)
	values
(1, 1),(2, 2),(3, 3),(4, 4),(5, 5),(6, 6),(7, 7),(8, 8),(9, 9),(10, 10);


insert into stock_personal_stock_account values
(3, 1000000, 1000000, 0, 1000000, 1200000, 200000,1),
(4, 1000000, 1000000, 0, 1000000, 1200000, 200000,2),
(5, 1000000, 1000000, 0, 1000000, 1200000, 200000,3),
(6, 1000000, 1000000, 0, 1000000, 1200000, 200000,4),
(7, 1000000, 1000000, 0, 1000000, 1200000, 200000,5),
(8, 1000000, 1000000, 0, 1000000, 1200000, 200000,6),
(9, 1000000, 1000000, 0, 1000000, 1200000, 200000,7),
(10, 1000000, 1000000, 0, 1000000, 1200000, 200000,8),
(11, 1000000, 1000000, 0, 1000000, 1200000, 200000,9),
(12, 1000000, 1000000, 0, 1000000, 1200000, 200000,10);


insert into stock_hold_stock_info
 values
(1, '000856', 1000, 1000, 200),
(2, '000856', 1000, 1000, 200),
(3, '000856', 1000, 1000, 200),
(4, '000856', 1000, 1000, 200),
(5, '000856', 1000, 1000, 200),
(6, '000856', 1000, 1000, 200),
(7, '000856', 1000, 1000, 200),
(8, '000856', 1000, 1000, 200),
(9, '000856', 1000, 1000, 200),
(10, '000856', 1000, 1000, 200);


INSERT INTO `stocktrading`.`stock_commission` ( `commissionID`,`stockID`, `commission_price`, `direction`, `commission_time`, `commission_account`, `stockholderID`, `state`, `remain`)
 VALUES
 ('2', '000856', '354', '0', '1493860816', '600', '2', '2', '600'),
 ('3', '000856', '360', '0', '1493860819', '700', '3', '2', '700'),
 ('4', '000856', '365', '0', '1493860820', '400', '4', '2', '400'),
 ('5', '000856', '376', '0', '1493860822', '600', '5', '2', '600'),
 ('1', '000856', '380', '0', '1493860849', '200', '1', '2', '200'),
 ('6', '000856', '352', '1', '1493860816', '500', '6', '2', '500'),
 ('7', '000856', '357', '1', '1493860819', '100', '7', '2', '100'),
 ('8', '000856', '360', '1', '1493860822', '200', '8', '2', '200'),
 ('9', '000856', '365', '1', '1493860816', '600', '9', '2', '600'),
 ('10', '000856', '370', '1', '1493860815', '600', '10', '2', '600'),
 ('11','000888','198','0','1493860815','400','1','2','400'),
 ('12','000888','198','1','1493860815','300','2','2','300');

insert into stock_deal
	values
(1,'000856',370, 1492772166, 100, 37000, 1, 6)


