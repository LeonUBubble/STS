<?php
return array(
    'SHOW_PAGE_TRACE'=>true,//显示页面trace的信息
);