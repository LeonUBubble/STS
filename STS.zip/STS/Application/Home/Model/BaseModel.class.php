<?php
namespace Home\Model;
use Think\Model;
class BaseModel extends Model
{


}