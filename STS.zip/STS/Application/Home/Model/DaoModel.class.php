<?php
namespace Home\Model;
use Think\Model;
class CommissionModel extends Model
{
    private $presentTime;//记录当前时间

    public function read($commissionid)
    {
        
    }
}