<?php
namespace Home\Model;
use Think\Model;
class CommissionModel extends Model
{
  
}