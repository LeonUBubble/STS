<?php
function show()
{
    echo "hello world";
}