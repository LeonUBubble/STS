<?php
namespace Home\Controller;
use Think\Controller;
use Home\Model\UserModel;
use Home\Model\CommonModel;
class IndexController extends Controller {
    public function index(){
        //$this->show('<style type="text/css">*{ padding: 0; margin: 0; } div{ padding: 4px 48px;} body{ background: #fff; font-family: "微软雅黑"; color: #333;font-size:24px} h1{ font-size: 100px; font-weight: normal; margin-bottom: 12px; } p{ line-height: 1.8em; font-size: 36px } a,a:hover{color:blue;}</style><div style="padding: 24px 48px;"> <h1>:)</h1><p>欢迎使用 <b>ThinkPHP</b>！</p><br/>版本 V{$Think.version}</div><script type="text/javascript" src="http://ad.topthink.com/Public/static/client.js"></script><thinkad id="ad_55e75dfae343f5a1"></thinkad><script type="text/javascript" src="http://tajs.qq.com/stats?sId=9347272" charset="UTF-8"></script>','utf-8');
        //echo "hello world";
        
        //URL_MODEL
        //0普通模式,http://localhost:8089/ThinkPHP/index.php/Home/Index/user/id/1.html
        //1默认,http://localhost:8089/ThinkPHP/index.php/Home/Index/user/id/1.html
        //2重写,http://localhost:8089/ThinkPHP/         /Home/Index/user/id/1.html
        //3默认,http://localhost:8089/ThinkPHP/index.php/Home/Index/user/id/1.html
        echo C(URL_MODEL),'<br/>';
        echo 'http://localhost:8089'.U('Home/Index/user',array('id'=>1),'html',false,'localhost:8089');
        //show();

        $user = M("User");
        $data = $user->select();
        $this->assign('list',$data);
        //$this->display();
        //dump($data);
        $this->display('user');//访问user视图（方法）
        
    }
    public function user()
    {
           // echo 'id is:'.$_GET['id'].'<br/>';
           //echo C('name');
           //trace('name',C('name'));
           //$this->display();
        $user = M('user');//M('')
        $data = $user->select();
        dump($data);
          /*  1.实例化基础模型
           $user = M('user');//M('')
          $data = $user->select();
          dump($data);
           2.实例化用户自定义模型
           $user = new UserModel();
          echo $user->getInfo();
           3.实例化公共模型
           $user = new CommonModel();
           echo $user->strmale('aaaa');
           4.实例化空模型
          $model = M();
          $model->query($sql);//读取日常 select
           $model->execute($sql);//写入 update insert */
        
        
    }

}